<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
    <form action="show.php" method="post">
    	Enter your name: <input type="text" name="name">
    	Enter your age: <input type="text" name="age">
    	<input type="submit" name="btnName">
    </form>
</body>
</html>