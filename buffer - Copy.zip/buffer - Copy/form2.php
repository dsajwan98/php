<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
   <form method="post" action="savedata.php">
   	  <table>
   	  	<tr>
   	  		<td>Enter Id</td>
   	  		<td><input type="text" name="txtId"></td>
   	  	</tr>

   	  	<tr>
   	  		<td>Enter name</td>
   	  		<td><input type="text" name="txtName"></td>
   	  	</tr>

   	  	<tr>
   	  		<td>Enter Email</td>
   	  		<td><input type="text" name="txtEmail"></td>
   	  	</tr>
   	  	<input type="submit" name="btnSubmit">
   	  </table>

   </form>
</body>
</html>