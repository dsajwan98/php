<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="showtable.php">
		Enter the number: <input type="number" name="txtnum">
	<br> <input type="submit" name="btnSubmit">
	</form>
	

</body>
</html>