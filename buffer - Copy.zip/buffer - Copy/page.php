<html>
<head>
   <title><?php
    echo "Woah!Its a waste"
   ?></title>
</head>
<body>
<?php
    $a=1;
    $b=2;
    echo $a+$b,"<br>";
    echo "Woah!Its a waste"
?>
</body>
</html>