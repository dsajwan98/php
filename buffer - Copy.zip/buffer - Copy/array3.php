<?php
   $languages=array("US"=>"English","India"=>"NewDelhi","France"=>"French");
   foreach ($languages as $key => $value) {
   	   echo "$key => $value <br>";
   }
?>