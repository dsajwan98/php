<?php
  print("<b>Using php power function</b><br>");
  $value=pow(5,3);
  echo $value."is the value of 5^3<br>";

?>