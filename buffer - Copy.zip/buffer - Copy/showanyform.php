<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post" action="showanydata.php">
		Enter the id: <input type="number" name="txtId">
	<br> <input type="submit" name="btnSubmit">
	</form>
	

</body>
</html>